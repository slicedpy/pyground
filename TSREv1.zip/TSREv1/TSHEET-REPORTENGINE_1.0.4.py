# Project Hydrogen (#0001)
# Title: TSHEET-REPORTENGINE.py
# Date: 22 JUNE 2018
# Contributors: Optum Care Practice Management; Charles E. Bezak; Tiffanee C. Lang
# Contact: tiffanee.lang@optum.com | 702-426-3385
# Purpose: Automate the process of the monthly T-Sheet Contract Compliance processing
#
# Requestor: Ingrid Patin
#
# Reoccurence:
# Monthly
#
# Source/Input:
# T-SHEETS Extraction (.csv)
#
# Destination/Output:
# Completed .XLSM (Macro-Enabled) worksheet for payroll as desginated by the
# 'Ryan CALC constriants'.
#
#
# Further Development:
# Progress_flag switching
# Fully Automated
# PDF email delivery
# Local interfacing for hosting server
# Authorization, Authentiation
# Holidays
# Dynamic window shifting
#
#
# Known Bugs, Issues and Fixes:
# Keep a look out for date formatting between the script and the XLSM
# Lack of error calling--manual operators required to validate
#
# Estimated Time of Completion
# 40.0 HOURS
#-----------------------------------------------------------------------------

# Import needed packages()
# datetime : Used for formatting and evaluation of date fields/data types
# calendar : Used for iterating through years, months, days, etc consistently
# os       : Allows the manipulation computing agnostic of operating system
# openpyxl : Version 2.5.4; Third-party Excel library to read/write from MS Excel
# time     : aligns the server(or host) clocking to create timestamps, etc; also throttling
# operator : Used for manipulating the indexing and sorting of list
# csv      : Used to migrate/manipulate data from csv into excel smoothly
#
# Input Dependencies
#
# TSheets Data (Month Year).csv (Extractions from T-SHEETS interface, whole month)
# each day represented on each sheet.
#
#   https://optum1.tsheets.com/page/login [ Authorization Required ]
#
#   Payroll Report >
#   Report Dates                   [Custom date range, 'mm/dd/YYYY' to 'mm/dd/YYYY']
#   Employee                       [NULL]
#   Groups/Employess               [all employees]
#   Show hour totals in            [Decimal (4.75)]
#   Sort employees by              [First Name]
#   Hide employees with zero hours [TRUE]
#
#   Report Exports >
#   Individual Timesheets (CSV)
#
# Constraint-Bound.xlsm
#   Macro-enabled Microsoft Excel spreadsheet pre-determined with formatting and
#   and formulas to accomodate payroll processing.
#
#
# Global Variables()
# cal = calendar.Calendar()
# Making the calendar global to keep all on the same date/time.
#
# Classes()
# N/A
#
#
#    
# Functions ()
#
# GetTimeSheet(year,month,TSheetInput='timesheet.csv')
#   This function is designated to gather the lines from the TSheets
#   extract and output a timesheet file that is compromised of
#   all times for the month central to the first sheet
#   and times entered respectively to the sheet by day
#
# CompletePayrollForm(PayrollWorkbook)
#   This function is designated to enter the data into the
#   XLSM workbook outfitted for the pre-determined functions
#   and formatting that ultimately outputs the timesheet
#   and shifts.

# CreateDatedSheets(year,month_num,XLSM_doc="MONTHYEAR.xlsm")
#   This function is used to copy the sheets based on their
#   day be it 'Weekday','Saturday' or 'Sunday'.
#

from datetime import *
from operator import itemgetter
import csv
import calendar
import os
import openpyxl as op
import time


cal = calendar.Calendar()

def GetTimeSheet(year,month,TSheetInput='timesheet.csv'):
    # REQUIRED:
    #   year (int 0000)
    #   month (int 0)
    #
    # OPTIONAL:
    #   TSheetInput (file .csv)
    
    
    # Establish a throttle to minimize corruption and possible file conflict
    # Create a local Month Year label variable to be consistent throughout the function.
    #time.sleep(2)
    job_title = calendar.month_name[month]+" "+ str(year)


    
    # Currently, the script must be run with only one (1) csv in the hosting
    # directory. The script is instructed to find the csv no matter the name.
    try:
        for root,dirs,files in os.walk(".", topdown=False):
            for name in files:
                filename,file_extension=os.path.splitext(name)
                if file_extension == '.csv':
                    TSheetInput = name

        print("| Now processing " + job_title+ " time entries from the \'" + TSheetInput + "\' file.")
    except:
        print ("ERROR 001 - A CSV file could not be found.")


    # Create a placeholder for the csv reader to output to
    # this also makes the data iteratable. Take note that
    # the reader only works in one direction. This will be result
    # returned with the respective shifts.
    TimeEntries = []

    # Open the timesheet file and process it through the csv module
    # using reader
    csv_timesheet = open(TSheetInput)
    reader = csv.reader(csv_timesheet,delimiter=",")


    # Create the workbook that will hold the data similar to a
    # user inputing the data by sheet by day.
    # activate it and get the first sheet name to be Month Year.
    #
    # The original input files started as .xlsx. Along the way it
    # seemed more seemless to have the data pull directly from
    # T-Sheets as a formatted csv. This output still proves beneficial
    # in the event of validation, auditting and the like
    output_filename = r"timesheet_out.xlsx"
    wb = op.Workbook()
    ws = wb.active
    ws.title=job_title


    # Translate the data from reader to a list object for more data
    # wrangling capabilites.
    TempDataStore = []
    for each_row in reader:
        # The values need to be sorted by hours largest to smallest.
        # The original data field from csv to reader to list parses as
        # a string. This proved challenge in sorting on it numerically
        # versus ordinally.
        #
        # Workaround consist of appending an extra ghost column purely
        # got sorting. If it's not feasible (ie a header gets in the way)
        # then default to 0.00 as it needs to be on the bottom anyway
        try:
            each_row.append(float(each_row[11]))
        except:
            each_row.append(float(0.00))
        TempDataStore.append(each_row)
        
    print('| Timesheet \'' + TSheetInput + '\' successfully loaded.\n')
        

    # Create sheets based on the right amount of days in a month
    # Sheet name formatting is M.DD; for example July 7 = '7.07'
    for each in cal.itermonthdays(year,month):
        if each !=0:
            sheet_name = str(month)+'.'+str(each).zfill(2)
            wb.create_sheet(sheet_name)

    # Designate  the first/top/upper row as the header row
    header= TempDataStore[0]

    # For each sheet in the workbook, activate the sheet, add the header and
    # add the appropriate data based on the sheet name; whole month being
    # the first sheet.
    for each_sheet in wb.sheetnames:
        active_sheet = wb[each_sheet]
        active_sheet.append(header)

        # The first sheet needs to be done first and seperate as the only
        # logic dictating its make up is straight from the raw csv.
        for row in TempDataStore[1:]:
            if active_sheet.title == job_title:
                active_sheet.append(row)

        # Sort all the data by the last field (that float of the hours
        # appended about 32 lines up. They need to be in descending order.
        TempDataStore.sort(key=lambda x: x[-1],reverse=True)

        # Poor use of error handling but the possibilities are limited.
        # If the month is present in the sheet name it needs to be completed.
        # the start_date (index 8) is what is reformatted and
        # determines which sheet a line will be added to. 
        for row in TempDataStore:
            try:
                dateEntry=datetime.strftime(datetime.strptime(row[8],"%Y-%m-%d %H:%M:%S"),"%m.%d")[1:]
                if str(month) in active_sheet.title and dateEntry == active_sheet.title:
                    active_sheet.append(row)
            except:
                # It is the header 'local_start_time' if an error occurs. skip
                continue
                
    # Close and save open data/input documents    
    csv_timesheet.close()
    wb.save('timesheet_out.xlsx')


    # Part of the original approach was an xlsx of time already shaped
    # turning the csv into an xlsx was the logically means to have the
    # best of both worlds. Settings can be authored to except either.
    hoursToLoad = op.load_workbook('timesheet_out.xlsx')

    # While the whole data file may have extra column names; this process
    # is only concerned with local_start_time, local_end_time and hours.
    #
    # This loop iterate through the output of the csv and inserts
    # the correct information dynamically based on the location of the
    # header. This is helpful in the event that the original documnent
    # headers shift. There is currently no provision if the columns are
    # renamed or re-type. Later releases will allow for the user to select
    # the columns from a drop-down or similar.
    for each in hoursToLoad.sheetnames:
        shifts = []
        active_sheet = hoursToLoad[each]
        shifts.append(active_sheet.title)

        header_column = active_sheet['1']
        start_time_column,end_time_column,duration_column ='','',''


        # Loop logic to determine which column address needs to be used
        # for the right data.
        for current_column in range(len(header_column)):
            current_label = header_column[current_column].value
            
            if current_label == 'local_start_time':
                start_time_column = header_column[current_column].column
                
            elif current_label == 'local_end_time':
                end_time_column = header_column[current_column].column
                
            elif current_label == 'hours':
                duration_column = header_column[current_column].column

        # For all rows below the first (the header), gather the date
        # (in the form of a sheet title), the start time, end time
        # and hours. Piece them together in order from them to be entered
        # agnostic of the original file.
        for row_iter in range(2,32):
            start_time = active_sheet[start_time_column+str(row_iter)]
            end_time = active_sheet[end_time_column+str(row_iter)]
            duration = active_sheet[duration_column+str(row_iter)]

            if start_time.value is not None:
                shifts.append(
                    [
                        str(active_sheet.title),
                        str(start_time.value),
                        str(end_time.value),
                        str(duration.value)
                        ]
                    )
        TimeEntries.append(shifts)
    # return (['0.00','01/01/1000 00:00','01/01/1000 00:00','0.00']
    return TimeEntries


# The XLSM workbook needs the data entered in the right places
# for the pre-determined functions and formatting to output
# the timesheet and shifts.
#
# Manual data processing is still necessary for outlier cases
# such as mandatory durations and holidays.
#
def CompletePayrollForm(PayrollWorkbook):

    # Establish a throttle to minimize corruption and possible file conflict
    #time.sleep(3)

    # The file should already be established. There is NO error handling for
    # the file--thus, if the user uploads January XLSM and processes February
    # timesheets there will be no notification otherwise.
    #
    # !!! WARNING !!! - Be aware that the parameters for this load_workbook
    # are imperative. The file needs to be enabled for writing (read_only),
    # have all previous functions operational (keep_vba) and have the formatting
    # predicted, especially for dates (guess_types)
    TimeSheetToComplete = op.load_workbook(PayrollWorkbook,read_only=False,keep_vba=True,guess_types=True)
    dataset = GetTimeSheet(2018,6)
    print("| Please wait while the Payroll Form is being completed...")


    # Set up an accumulator in order to enable validation at the end of the script
    total_rows = 0
    for each in TimeSheetToComplete.sheetnames:

        # Activate the sheet and redirect to cell AH. There, if the template does
        # not change, should be the value of 'T-Sheets Data Drop'
        active_sheet = TimeSheetToComplete[each]
        headerCell = active_sheet['AH']
        
        for cellValue in headerCell:
            if cellValue.value == 'T-Sheets Data Drop':

                # If the AH cell is proven to be the T-Sheets Data Drop table set
                # Activate the area and prepare to enter the data
                timeCard = active_sheet['AI'+str(cellValue.row+2):'AK'+str(cellValue.row+24)]

                # With the entire dataset, evaluate whether or not the data needs
                # to be on this sheet. If so, add it with the correct formatting.
                #
                # Something to note: it might be more efficient to eliminate the
                # instance/index from the dataset list if the entry has in fact
                # been matched with a worksheet. This way, the list is diminishing
                # and hopefully apt to work/index faster.
                for each in dataset:
                    if each[0] == active_sheet.title:
                        input_data = each[1:]
                        for line,cell in zip(input_data,timeCard):
                            cell[2].number_format = '0.00'
                            cell[0].value=datetime.strptime(line[1],"%Y-%m-%d %H:%M:%S")
                            cell[1].value=datetime.strptime(line[2],"%Y-%m-%d %H:%M:%S")
                            cell[2].value=float(line[3])
                  
                        total_rows += int(len(each[1:]))
                    # Poor practice - this error handling simply lets the script
                    # continue. For now, this will suffice but needs to be addressed
                    # in the next release.
                    else:
                        continue

    print("| COMPLETE.\n\n")
    print("| "+str(total_rows) + " were succesfully processed.")

    TimeSheetToComplete.save(PayrollWorkbook)
    print("| SCRIPT END TIME: "+datetime.strftime(datetime.now(),'%m/%d/%Y %H:%M:%S %p')+"\n")

    # Make the user interact with the script for it to close versus it closing
    # at the termination flag.
    User_Close = input(">>>   Task is complete. Please review files saved in the directory. <<<")



def CreateDatedSheets(year,month_num,XLSM_doc="MONTHYEAR.xlsm"):
    #time.sleep(2)
    for root,dirs,files in os.walk(".", topdown=False):
        for name in files:
            filename,file_extension=os.path.splitext(name)
            if file_extension == '.xlsm':
                XLSM_doc = name
                
    print('| Processing XLSM template \'' +XLSM_doc+ '\' with dated worksheets.')
    
    wb = op.load_workbook(XLSM_doc,read_only=False,keep_vba=True)

    for each in cal.itermonthdays(year,month_num):
        if each !=0:
            sheet_name = str(month_num)+'.'+str(each).zfill(2)
            datetime_object = datetime.strptime(str(year)+'-'+str(month_num).zfill(2)+'-'+str(each).zfill(2), '%Y-%m-%d')
            if calendar.day_name[datetime_object.weekday()] == 'Sunday':
                active_sheet = wb['Sunday']
                target = wb.copy_worksheet(active_sheet)
                target.title = sheet_name
                target['B1'].value=datetime.strptime(str(month_num)+"/"+str(each)+"/"+str(year) + " 7:00:00 AM","%m/%d/%Y %H:%M:%S %p")
       
                
            elif calendar.day_name[datetime_object.weekday()] == 'Saturday':
                active_sheet = wb['Saturday']
                target = wb.copy_worksheet(active_sheet)
                target.title = sheet_name
                target['B1'].value=datetime.strptime(str(month_num)+"/"+str(each)+"/"+str(year) + " 7:00:00 AM","%m/%d/%Y %H:%M:%S %p")
              
                
            else:
                active_sheet = wb['Weekday']
                target = wb.copy_worksheet(active_sheet)
                target.title = sheet_name
                target['B1'].value=datetime.strptime(str(month_num)+"/"+str(each)+"/"+str(year) + " 7:00:00 AM","%m/%d/%Y %H:%M:%S %p")
         
                
    wb.save('outputPayRoll.xlsm')
    print("| COMPLETE.\n")

if __name__ == "__main__":
    print("| SCRIPT START TIME: "+datetime.strftime(datetime.now(),'%m/%d/%Y %H:%M:%S %p')+"\n")
    #time.sleep(2)
    CreateDatedSheets(2018,6)
    CompletePayrollForm('outputPayRoll.xlsm')

.LOG

PROJECT HYDROGEN

## Supply development notes...eventually. ##
10:37 AM 6/26/2018


v1.0.0 Known Issues, Bugs and Fixes:

Cell formulas to populate payroll schedule (on left side) not picking up dates. Formulas suspected to be corrupted within development. Getting fresh version for testing.

Current code configured to pull based on daily tab extraction. Needs to be updated to pull one file with respective dates.

Formatting needs to be tested

TSHEETS access needed to be confirmed for month by month testing.


12:18 PM 6/26/2018

These damn dates and their format...
3:29 PM 6/26/2018


Fix the B1 bug--date not selecting correct date
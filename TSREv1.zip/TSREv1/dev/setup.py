# Setup file for py to exe


from cx_Freeze import setup, Executable

base = None    

executables = [Executable("C:\\Users\\tlang4\\Desktop\\01_Hyrdogen\\TSHEET-REPORTENGINE_1.0.4.py", base=base)]

packages = ["idna"]
options = {
    'build_exe': {    
        'packages':packages,
    },    
}

setup(
    name = "<any name>",
    options = options,
    version = "<any number>",
    description = '<any description>',
    executables = executables
)

#setup.py

import sys, os
from cx_Freeze import setup, Executable

__version__="1.0.0"

include_files = []
excludes = []
packages = ['datetime','calendar','os','openpyxl','time','operator','csv']

target = Executable(
        script='C:\\Users\\tlang4\\Desktop\\01_Hyrdogen\\tsheet-reportengine.py',
        base='Win32GUI',
        icon='C:\\Users\\tlang4\\AppData\\Local\\Programs\\Python\\Python36\\optum_ico.ico',
        targetName="TSREv1.exe")

setup(
    name='T-Sheet_ReportEngine',
    description='Automation tool for monthly reporting.exe',
    version=__version__,
    options={"build.exe":{
        'packages': packages,
        'include_files': include_files,
        'excludes': excludes,
        'include_msvcr': True,
        }},
    executables = [target]
    )

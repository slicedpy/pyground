import csv




import pyodbc



import getpass



from datetime import datetime as dtime


import datetime


import json


import urllib


import sys


import time


import os


from getpass import *


from path import Path


from staticmap import * # StaticMap, CircleMarker
from PIL import Image,ImageFont,ImageDraw
import xlsxwriter as xl














os.system("mode con cols=140 lines=40")














######################################
global cnxn
global db_cursor
global current_profile

global prod_cnxn
global prod_db_cursor

global run_weather_station
global walmart_store

global run_img_nm
#######################################

















def gainAccess():
    global cnxn
    global db_cursor
    global current_profile

    cxn_successful = False

    while cxn_successful == False:

        dbname = raw_input("Choose a Connection-[1-DEV|5-TEST|0-PROD]: ") or '5'
        userName = raw_input("Please enter username: ") or 'tlang5_dba'
        pword = getpass("Enter password for "+ str(userName) + ":") or 'tl00tl'

        db_dict = {'1':'testedw',
                   'DEV':'testedw',
                   '5':'testedw',
                    'TEST':'testedw',
                   '0':'edw',
                   'PROD':'edw'}; 

        cnxn = pyodbc.connect('DRIVER={TERADATA};DBCNAME='+\
                              str(db_dict[dbname.upper()])+\
                              ';UID='+ userName + ';PWD=' + pword + ';', autocommit=True)

        db_cursor = cnxn.cursor()
        current_profile = [str(db_dict[dbname.upper()]),userName]
        cxn_successful = True

    #print "gainAcess successful!"














def prod_gainAccess():
    global prod_cnxn
    global prod_db_cursor

    prod_cnxn = pyodbc.connect('DRIVER={TERADATA};DBCNAME=edw;UID=tlang5_dba;PWD=tl00tl;',autocommit=True)

    prod_db_cursor = prod_cnxn.cursor()

    #print "Access granted to prod_gainAccess"
    












def displayBanner():
    with open("banner.txt","r") as banner_text:
        print banner_text.read()

    gainAccess()













def runQuery(query):
    global cnxn
    global db_cursor
    global propCreds


    db_cursor.execute(query)
    cnxn.commit()

    try:
        return db_cursor.fetchall()
    except:
        print "."
        












def inQuery(query):
    global cnxn
    global db_cursor
    global propCreds


    db_cursor.execute(query)
    cnxn.commit()
        
        











def prod_runQuery(query):
    global prod_cnxn
    global prod_db_cursor

    prod_db_cursor.execute(query)
    prod_cnxn.commit()

    try:
        return prod_db_cursor.fetchall()
    except:
        print "slight error in prod_runQuery"
















def httpPrepare(inString):
    return inString.replace(" ","+").upper()
    #print "HTTP request made"

















def createStaticMap(img_coords,city_name):
    global run_img_nm

    run_img_nm = ("staticMaps"+os.sep+city_name).upper()+'.png'
    
    m = StaticMap(525, 325, url_template='http://a.tile.osm.org/{z}/{x}/{y}.png')

    marker_outline = CircleMarker(img_coords,"#02395D",16)
    marker = CircleMarker(img_coords,"#087FCD",14) #FFAA00,ED2900

    m.add_marker(marker_outline)
    m.add_marker(marker)

    image = m.render(zoom=4)
    image.save(run_img_nm)
    #print "Image created"

   
    map_img = Image.open(run_img_nm)
    markup = ImageDraw.Draw(map_img)
    print_font = ImageFont.truetype("arial.ttf", 17)
    markup.text((365, 300),str(latitude)+","+str(longitude),(0,0,0),font=print_font)
    map_img.save(run_img_nm)
    #print "Image Watermark Completed"















def joinStoreWeather(weather,walmart,chart_image):
    prod_gainAccess()

    quo = "EXECUTE tlang5_dba.pos_walmart_store(\'%"+walmart+"\');"
    #print quo

    xCompileWeather = "EXECUTE tlang5_dba.compile_weather_pos (\'"+weather+"\',\'%"+walmart+"\');"
    #print xCompileWeather
    #print "Working on it..."
    
    ret = prod_runQuery(quo)

    pos_date_data =[]
    store_data = []
    pos_sold_data = []
    pos_onorder_data = []
    t_avg_data = []


    for each in ret:
        que = "INSERT INTO tlang5_dba.template VALUES(\'"+str(each[0])+"\',\'"+\
              str(each[1])+"\',\'"+str(each[2])+"\',\'"+str(each[3])+"\',\'"+ str(each[4])+"\',\'"+str(each[5])+\
              "\',\'"+str(each[6])+"\',\'"+str(each[7])+"');"

        #print que
        inQuery(que)

    #print "Values inserted"

    for each in runQuery(xCompileWeather):
        pos_date_data.append(each[0])
        store_data.append(each[1])
        pos_sold_data.append(each[2])
        pos_onorder_data.append(each[3])
        t_avg_data.append(each[4])
        
        #print str(each[0])+ "    |    " + str(each[1]) + "    |    " + str(each[2])+ "    |    " + str(each[3])+ "    |    " + str(each[4])

    #print "Creating Excel Plot"
    
    workbook = xl.Workbook("plots"+os.sep+walmart_store + '_plotter.xlsx')
    
    worksheet = workbook.add_worksheet('scatter_plot')




    
    bold = workbook.add_format({'bold':1,'bg_color':'#2a2b2d','font_color':'#ffffff'})
    
    darken_bg = workbook.add_format({'bg_color':'#2a2b2d','font_color':'#ffffff'})    
    for row in range(1,43):
        worksheet.set_row(row,None,darken_bg)
    
    date_format = workbook.add_format({'num_format': '[$-en-US]dd-mmm-yyyy',
                                      'align': 'left','bg_color':'#2a2b2d','font_color':'#ffffff'})

    
    darken_bg.set_pattern(1)
    bold.set_pattern(1)
    date_format.set_pattern(1)
    

    headings =['POS_DATE','STORE','POS_SOLD','POS_ONORDER','T_AVG']

    data = [pos_date_data,store_data,pos_sold_data,\
            pos_onorder_data,t_avg_data]

    worksheet.write_row('A1',headings, bold)
    worksheet.write_column('A2',data[0],date_format)
    worksheet.write_column('B2',data[1])
    worksheet.write_column('C2',data[2])
    worksheet.write_column('D2',data[3])
    worksheet.write_column('E2',data[4])

    worksheet.set_column(0,1,30)

    
    scatter_plot1 = workbook.add_chart({'type':'scatter'})

    scatter_plot1.add_series({
        'name': '=scatter_plot!$E$1',
        'categories': '=scatter_plot!$A$2:$A$'+str(len(pos_date_data)+1)+'',
        'values': '=scatter_plot!$E$2:$E$'+str(len(pos_date_data)+1)+'',
        'trendline': {'type': 'moving_average','period':25,\
                      'line':{'color':'#DF1D35',
                              'width':3.5,},
                      },
        'marker': {'type': 'none'},
        })

    scatter_plot1.add_series({
        'name': '=scatter_plot!$C$1',
        'categories': '=scatter_plot!$A$2:$A$'+str(len(pos_date_data)+1),
        'values': '=scatter_plot!$C$2:$C$'+str(len(pos_date_data)+1),
        'trendline': {'type': 'moving_average','period':25,\
                      'line':{'color':'#c2ff1c',
                              'width':3.5,},
                      },
        'marker': {'type': 'none'},
        })

    
    scatter_plot1.set_title({'name': 'Weather Behavior for Walmart #'+ walmart_store,
                             'name_font': {'color':'white'}
                             })
    
    scatter_plot1.set_x_axis({'name':'Date of POS/Tempature Record','date_axis': True,
                              'min': datetime.date(2016, 1,1),'max': datetime.date(2016, 12,31),
                              'major_gridlines':{'visible':False},
                              'name_font':{'name':'Arial','color':'white','size':14},
                              'num_font':{'color':'white'},
                              'major_tick_mark': 'none',
                              'minor_tick_mark': 'none'
                              })
    
    scatter_plot1.set_y_axis({'name': 'Value (Temperature (F) / QTY SOLD',
                              'major_gridlines':{'visible':False},
                              'name_font':{'name':'Arial','color':'white','size':14},
                              'num_font':{'color':'white'},
                              })

    #scatter_plot1.set_style(10)
    scatter_plot1.set_chartarea({'border': {'none': True},'fill':{'color': '#2a2b2d'}})
    scatter_plot1.set_plotarea({'fill':   {'color': '#2a2b2d'}})

    worksheet.insert_chart('F2',scatter_plot1,{'x_offset': 25, 'y_offset': 10})
    scatter_plot1.set_size({'width':1203,'height':608})

    # Insert an image.
    worksheet.insert_image('T3',chart_image+'.png',{'x_scale': 0.60, 'y_scale': 0.60})

    workbook.close()

    print "Workbook ready"














t = 1
displayBanner()

while t == 1:
    
    user_choice = str(raw_input("\n\n>>>")).upper() or "G"

    if user_choice == "SH":
        print current_profile

    if user_choice == "L":
        print 
        gatherCredentials(change="YES")
    
    if user_choice == "G":
        street = raw_input("address: ") or "1 FRUIT OF THE LOOM DRIVE"
        city = raw_input("city: ") or "BOWLING GREEN"
        state = raw_input("state: ") or "KY"

        #print "\nRequest recieved"


        try:
            census_return = urllib.urlopen("https://geocoding.geo.census.gov/geocoder/geographies/address?street="+httpPrepare(street)+"&city="+httpPrepare(city)+"&state="+httpPrepare(state)+"&benchmark=Public_AR_Census2010&vintage=Census2010_Census2010&layers=14&format=json")

            results = json.loads(census_return.read())

            latitude = results["result"]["addressMatches"][0]["coordinates"]["y"]
            longitude = results["result"]["addressMatches"][0]["coordinates"]["x"]

            img_coords = (longitude,latitude)

            
        except:
            print "\nAddress not found from Census Geocoder\n"
                   


        try:
            data_returned = runQuery(""'EXECUTE tlang5_dba.find_nearest_weather_station ('+str(latitude)+','+str(longitude)+',25);')[0]
            print "connected"
            
            chosen_weather_station = data_returned[0]
            weather_station_name = data_returned[1]
            distance_from_address = str(data_returned[2]) + " miles\n"

            run_weather_station = chosen_weather_station
            

            
            metadata_line = "Nearest weather station: " + chosen_weather_station +\
                            "\nWeather Station Name: " + weather_station_name +\
                            "\nDistance from entered location: " + distance_from_address

            for char in metadata_line:
                time.sleep(0.01)
                sys.stdout.write(char)
                sys.stdout.flush()

            img_name = (street[0:4]+'_'+city).replace(" ","")
            createStaticMap(img_coords,img_name)

            print "\n------------------------Nearest retailers------------------------"
            
        except:
            print "Weather station can't be printed"


            

        try:
            data_returned = runQuery(""'EXECUTE tlang5_dba.find_nearest_retailer ('+str(latitude)+','+str(longitude)+');')
            print "Hurdle 1"
            
            for each in data_returned:
                ln_print = "\n"

                if each[0] == 'WALMART':
                    walmart_store = str(each[1])
                    
                for i in each:
                    ln_print += str(i)+" "*(28-len(str(i))) + "|"

                    
                for char in ln_print:
                    time.sleep(0.01)
                    sys.stdout.write(char)
                    sys.stdout.flush()

            print "\nGot this going!"


            print "\n\n"
            data_returned = runQuery(""'EXECUTE tlang5_dba.get_weather_by_station(\''+chosen_weather_station+'\');')

            print "Hurdle 2"


            header_titles = ["OBS_DATE","TMAX","TMIN","PRCP","SNOW","SNWD"]
            header = ""
            for each in header_titles:
                header += str(each)+" "*(18-len(str(each))) + "|"


            #print header
            #print walmart_store

            for each in data_returned:
                ln_print = "\n"
                buffy = 60
                for i in each:
                    ln_print += str(i)+" "*(18-len(str(i))) + "|"
                    
##                for char in ln_print:
##                    #time.sleep(0.0001)
##                    sys.stdout.write(char)
##                    sys.stdout.flush()
        except:
            print "Yeah this"



        try:
            
            
            joinStoreWeather(run_weather_station,walmart_store,"staticMaps"+os.sep+img_name)
            inQuery("delete from tlang5_dba.template")
            
        except:
            print "\nERROR OCCURED....SUCKA!"



       



from staticmap import StaticMap, CircleMarker

m = StaticMap(525, 325, url_template='http://a.tile.osm.org/{z}/{x}/{y}.png')

marker_outline = CircleMarker((-86.41096,36.956696),"#02395D",18)
marker = CircleMarker((-86.41096,36.956696),"#087FCD",12) #FFAA00,ED2900

m.add_marker(marker_outline)
m.add_marker(marker)

image = m.render(zoom=14)
image.save('marker.png')

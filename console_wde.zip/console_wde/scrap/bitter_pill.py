from PIL import Image,ImageFont,ImageDraw 

map_img = Image.open("marker.png")
markup = ImageDraw.Draw(map_img)
print_font = ImageFont.truetype("arial.ttf", 16)
markup.text((425, 300),"Sample Text",(0,0,0),font=print_font)
map_img.save('marker_marked.png')

import teradata
import pyodbc
import sys


udaExec = teradata.UdaExec (appName="Test App", version="1.3",
        logConsole=False)

session = udaExec.connect(method="odbc", dsn="TERADATA_TEST",
        username="tlang5_dba", password="tl00tl");

cursor =  session.cursor();

cnt = cursor.execute("SELECT * FROM ERP_S.DIM_INVENTORY_ITEM").rowcount;

print cnt


import csv
import pyodbc
import getpass
from datetime import datetime as dtime
import datetime


import json
import urllib
import sys
import time
import os
from getpass import *
from path import Path

os.system("mode con cols=140 lines=40")


def displayBanner():
    with open("banner.txt","r") as banner_text:
        print banner_text.read()


##    with open("creds.txt","r") as cred_file:
##        lines = 0
##        for each in cred_file:
##            lines += 1
                

def httpPrepare(inString):
    return inString.replace(" ","+").upper()


def gatherCredentials():

    
    user_driverInput = str(raw_input("ENTER DRIVER [TERADATA]: " )) or "TERADATA"
    user_dbcInput = str(raw_input("ENTER DATABASE CONNECTION [TESTEDW]: ")) or "TESTEDW"
    user_uidInput = str(raw_input("ENTER USERNAME: ")) or "tlang5_dba"
    user_pwdInput = getpass()

    #with open("creds.txt","w") as cred_file:
        #cred_file.write("DRIVER="+user_driverInput+";DBCNAME="+user_dbcInput+";UID="+user_uidInput+";PWD="+user_pwdInput+";")

    return "DRIVER="+user_driverInput+";DBCNAME="+user_dbcInput+";UID="+user_uidInput+";PWD="+user_pwdInput+";"



def runQuery(query):
    with open("creds.txt","r") as cred_file:
        cnxn = pyodbc.connect("DRIVER=TERADATA;DBCNAME=TESTEDW;UID=tlang5_dba;PWD=tl00tl;",autocommit=True)
        db_cursor = cnxn.cursor()

        db_cursor.execute(query)
        cnxn.commit()
        
        return db_cursor.fetchall()


t = 1
displayBanner()
while t == 1:
    user_choice = str(raw_input("\n\n>>>")).upper() or "G"
    
    if user_choice == "G":
        street = raw_input("address: ") or "1 FRUIT OF THE LOOM DRIVE"
        city = raw_input("city: ") or "BOWLING GREEN"
        state = raw_input("state: ") or "KY"

        print "\nRequest recieved"

        try:
            census_return = urllib.urlopen("https://geocoding.geo.census.gov/geocoder/geographies/address?street="+httpPrepare(street)+"&city="+httpPrepare(city)+"&state="+httpPrepare(state)+"&benchmark=Public_AR_Census2010&vintage=Census2010_Census2010&layers=14&format=json")
            print "Got it"

            results = json.loads(census_return.read())
            print "Okay"

            latitude = results["result"]["addressMatches"][0]["coordinates"]["y"]
            longitude = results["result"]["addressMatches"][0]["coordinates"]["x"]

            print "Coordinate gained"

            data_returned = runQuery(""'EXECUTE tlang5_dba.find_nearest_weather_station ('+str(latitude)+','+str(longitude)+',15);')[0]
            print "Got this far now."

            chosen_weather_station = data_returned[0]
            weather_station_name = data_returned[1]
            distance_from_address = str(data_returned[2]) + " miles\n"
            
            metadata_line = "Nearest weather station: " + chosen_weather_station +\
                            "\nWeather Station Name: " + weather_station_name +\
                            "\nDistance from entered location: " + distance_from_address

            for char in metadata_line:
                time.sleep(0.01)
                sys.stdout.write(char)
                sys.stdout.flush()

            print "\n------------------------Nearest retailers------------------------"

            data_returned = runQuery(""'EXECUTE tlang5_dba.find_nearest_retailer ('+str(latitude)+','+str(longitude)+');')
            for each in data_returned:
                ln_print = "\n"
                for i in each:
                    ln_print += str(i)+" "*(28-len(str(i))) + "|"
                    
                for char in ln_print:
                    time.sleep(0.01)
                    sys.stdout.write(char)
                    sys.stdout.flush()


            print "\n\n"
            data_returned = runQuery(""'EXECUTE tlang5_dba.get_weather_by_station(\''+chosen_weather_station+'\');')


            header_titles = ["OBS_DATE","TMAX","TMIN","PRCP","SNOW","SNWD"]
            header = ""
            for each in header_titles:
                header += str(each)+" "*(18-len(str(each))) + "|"


            print header

            for each in data_returned:
                ln_print = "\n"
                buffy = 60
                for i in each:
                    ln_print += str(i)+" "*(18-len(str(i))) + "|"
                    
                for char in ln_print:
                    time.sleep(0.0001)
                    sys.stdout.write(char)
                    sys.stdout.flush()

 
                    

        except:
            print "\nAddress not found from Census Geocoder\n"

import csv
import pyodbc
import getpass
from datetime import datetime as dtime
import datetime


import json
import urllib
import sys
import time
import os
from getpass import *
from path import Path
from staticmap import * # StaticMap, CircleMarker
from PIL import Image,ImageFont,ImageDraw
import xlsxwriter





os.system("mode con cols=140 lines=40")

global cnxn
global db_cursor
global current_profile


def gainAccess():
    global cnxn
    global db_cursor
    global current_profile

    dbname = raw_input("Choose a Connection-[1-DEV|5-TEST|0-PROD]: ") or '5'
    userName = raw_input("Please enter username: ") or 'tlang5_dba'
    pword = getpass("Enter password for "+ str(userName) + ":") or 'tl00tl'

    db_dict = {'1':'testedw',
               'DEV':'testedw',
               '5':'testedw',
                'TEST':'testedw',
               '0':'edw',
               'PROD':'edw'}; 

    cnxn = pyodbc.connect('DRIVER={TERADATA};DBCNAME='+\
                          str(db_dict[dbname.upper()])+\
                          ';UID='+ userName + ';PWD=' + pword + ';', autocommit=True)

    db_cursor = cnxn.cursor()
    current_profile = [str(db_dict[dbname.upper()]),userName]


def displayBanner():
    with open("banner.txt","r") as banner_text:
        print banner_text.read()

    gainAccess()


def runQuery(query):
    global cnxn
    global db_cursor
    global propCreds


    db_cursor.execute(query)
    cnxn.commit()
        
    return db_cursor.fetchall()


def httpPrepare(inString):
    return inString.replace(" ","+").upper()


def createStaticMap(img_coords):
    m = StaticMap(525, 325, url_template='http://a.tile.osm.org/{z}/{x}/{y}.png')

    marker_outline = CircleMarker(img_coords,"#02395D",18)
    marker = CircleMarker(img_coords,"#087FCD",14) #FFAA00,ED2900

    m.add_marker(marker_outline)
    m.add_marker(marker)

    image = m.render(zoom=14)
    image.save('marker.png')

def createImgWatermark():
    map_img = Image.open("marker.png")
    markup = ImageDraw.Draw(map_img)
    print_font = ImageFont.truetype("arial.ttf", 16)
    markup.text((372, 300),str(latitude)+","+str(longitude),(0,0,0),font=print_font)
    map_img.save('marker_marked.png')



def createXlsxFromFindings():
    workbook = xlsxwriter.Workbook('pos_weather_0299.xlsx')
    worksheet = workbook.add_worksheet('walmart0299_16_weather')
    bold =  workbook.add_format({'bold':1})

    # Add the worksheet data that the charts will refer to.
    headings = ["date_id","cust_id","store_num","retail_nm","city","state","sold_qty","onorder_qty"]
    data = [
    









t = 1
displayBanner()

while t == 1:
    
    user_choice = str(raw_input("\n\n>>>")).upper() or "G"

    if user_choice == "SH":
        print current_profile

    if user_choice == "L":
        print 
        gatherCredentials(change="YES")
    
    if user_choice == "G":
        street = raw_input("address: ") or "1 FRUIT OF THE LOOM DRIVE"
        city = raw_input("city: ") or "BOWLING GREEN"
        state = raw_input("state: ") or "KY"

        print "\nRequest recieved"


        

        try:
            census_return = urllib.urlopen("https://geocoding.geo.census.gov/geocoder/geographies/address?street="+httpPrepare(street)+"&city="+httpPrepare(city)+"&state="+httpPrepare(state)+"&benchmark=Public_AR_Census2010&vintage=Census2010_Census2010&layers=14&format=json")

            results = json.loads(census_return.read())

            latitude = results["result"]["addressMatches"][0]["coordinates"]["y"]
            longitude = results["result"]["addressMatches"][0]["coordinates"]["x"]

            img_coords = (longitude,latitude)
            
        except:
            print "\nAddress not found from Census Geocoder\n"
            
            


        try:
            data_returned = runQuery(""'EXECUTE tlang5_dba.find_nearest_weather_station ('+str(latitude)+','+str(longitude)+',15);')[0]
            print "connected"
            
            chosen_weather_station = data_returned[0]
            weather_station_name = data_returned[1]
            distance_from_address = str(data_returned[2]) + " miles\n"
            
            metadata_line = "Nearest weather station: " + chosen_weather_station +\
                            "\nWeather Station Name: " + weather_station_name +\
                            "\nDistance from entered location: " + distance_from_address

            for char in metadata_line:
                time.sleep(0.01)
                sys.stdout.write(char)
                sys.stdout.flush()

            print "\n------------------------Nearest retailers------------------------"
            
        except:
            print "Weather station can't be printed"


            

        try:
            data_returned = runQuery(""'EXECUTE tlang5_dba.find_nearest_retailer ('+str(latitude)+','+str(longitude)+');')
            for each in data_returned:
                ln_print = "\n"
                for i in each:
                    ln_print += str(i)+" "*(28-len(str(i))) + "|"
                    
                for char in ln_print:
                    time.sleep(0.01)
                    sys.stdout.write(char)
                    sys.stdout.flush()


            print "\n\n"
            data_returned = runQuery(""'EXECUTE tlang5_dba.get_weather_by_station(\''+chosen_weather_station+'\');')


            header_titles = ["OBS_DATE","TMAX","TMIN","PRCP","SNOW","SNWD"]
            header = ""
            for each in header_titles:
                header += str(each)+" "*(18-len(str(each))) + "|"


            print header

            for each in data_returned:
                ln_print = "\n"
                buffy = 60
                for i in each:
                    ln_print += str(i)+" "*(18-len(str(i))) + "|"
                    
                for char in ln_print:
                    #time.sleep(0.0001)
                    sys.stdout.write(char)
                    sys.stdout.flush()
        except:
            print "Yeah this"



        try:
            createStaticMap(img_coords)
            createImgWatermark()
        except:
            print "Baby Agent"
            
       



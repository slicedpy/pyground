import csv
import pyodbc
import getpass
from datetime import datetime as dtime
import datetime


import json
import urllib
import sys
import time
import os
from getpass import *
from path import Path
from staticmap import * # StaticMap, CircleMarker
from PIL import Image,ImageFont,ImageDraw



os.system("mode con cols=140 lines=40")

global cnxn
global db_cursor
global current_profile

global prod_cnxn
global prod_db_cursor

global run_weather_station
global walmart_store



def gainAccess():
    global cnxn
    global db_cursor
    global current_profile

    dbname = raw_input("Choose a Connection-[1-DEV|5-TEST|0-PROD]: ") or '5'
    userName = raw_input("Please enter username: ") or 'tlang5_dba'
    pword = getpass("Enter password for "+ str(userName) + ":") or 'tl00tl'

    db_dict = {'1':'testedw',
               'DEV':'testedw',
               '5':'testedw',
                'TEST':'testedw',
               '0':'edw',
               'PROD':'edw'}; 

    cnxn = pyodbc.connect('DRIVER={TERADATA};DBCNAME='+\
                          str(db_dict[dbname.upper()])+\
                          ';UID='+ userName + ';PWD=' + pword + ';', autocommit=True)

    db_cursor = cnxn.cursor()
    current_profile = [str(db_dict[dbname.upper()]),userName]



def prod_gainAccess():
    global prod_cnxn
    global prod_db_cursor

    prod_cnxn = pyodbc.connect('DRIVER={TERADATA};DBCNAME=edw;UID=tlang5_dba;PWD=tl00tl;',autocommit=True)

    prod_db_cursor = prod_cnxn.cursor()
    


def displayBanner():
    with open("banner.txt","r") as banner_text:
        print banner_text.read()

    gainAccess()


def runQuery(query):
    global cnxn
    global db_cursor
    global propCreds


    db_cursor.execute(query)
    cnxn.commit()

    try:
        return db_cursor.fetchall()
    except:
        print "."
        

def inQuery(query):
    global cnxn
    global db_cursor
    global propCreds


    db_cursor.execute(query)
    cnxn.commit()
        
        

def prod_runQuery(query):
    global prod_cnxn
    global prod_db_cursor

    prod_db_cursor.execute(query)
    prod_cnxn.commit()

    try:
        return prod_db_cursor.fetchall()
    except:
        print "slight error"


def httpPrepare(inString):
    return inString.replace(" ","+").upper()


def createStaticMap(img_coords,city_name):
    m = StaticMap(525, 325, url_template='http://a.tile.osm.org/{z}/{x}/{y}.png')

    marker_outline = CircleMarker(img_coords,"#02395D",18)
    marker = CircleMarker(img_coords,"#087FCD",14) #FFAA00,ED2900

    m.add_marker(marker_outline)
    m.add_marker(marker)

    image = m.render(zoom=14)
    image.save(city_name+'.png')

def createImgWatermark(city_name):
    map_img = Image.open(city_name+'.png')
    markup = ImageDraw.Draw(map_img)
    print_font = ImageFont.truetype("arial.ttf", 17)
    markup.text((374, 300),str(latitude)+","+str(longitude),(0,0,0),font=print_font)
    map_img.save(city_name+'.png')



def extraFunction(weather,walmart):
    prod_gainAccess()

    quo = "EXECUTE tlang5_dba.pos_walmart_store(\'%"+walmart+"\');"
    print quo

    xCompileWeather = "EXECUTE tlang5_dba.compile_weather_pos (\'"+weather+"\',\'%"+walmart+"\');"
    print xCompileWeather
    
    ret = prod_runQuery(quo)

    for each in ret:
        que = "INSERT INTO tlang5_dba.template VALUES(\'"+str(each[0])+"\',\'"+\
              str(each[1])+"\',\'"+str(each[2])+"\',\'"+str(each[3])+"\',\'"+ str(each[4])+"\',\'"+str(each[5])+\
              "\',\'"+str(each[6])+"\',\'"+str(each[7])+"');"

        #print que
        inQuery(que)

    for each in runQuery(xCompileWeather):
        print str(each[0])+ "    |    " + str(each[1]) + "    |    " + str(each[2])+ "    |    " + str(each[3])+ "    |    " + str(each[4])


t = 1
displayBanner()

while t == 1:
    
    user_choice = str(raw_input("\n\n>>>")).upper() or "G"

    if user_choice == "SH":
        print current_profile

    if user_choice == "L":
        print 
        gatherCredentials(change="YES")
    
    if user_choice == "G":
        street = raw_input("address: ") or "1 FRUIT OF THE LOOM DRIVE"
        city = raw_input("city: ") or "BOWLING GREEN"
        state = raw_input("state: ") or "KY"

        print "\nRequest recieved"


        try:
            census_return = urllib.urlopen("https://geocoding.geo.census.gov/geocoder/geographies/address?street="+httpPrepare(street)+"&city="+httpPrepare(city)+"&state="+httpPrepare(state)+"&benchmark=Public_AR_Census2010&vintage=Census2010_Census2010&layers=14&format=json")

            results = json.loads(census_return.read())

            latitude = results["result"]["addressMatches"][0]["coordinates"]["y"]
            longitude = results["result"]["addressMatches"][0]["coordinates"]["x"]

            img_coords = (longitude,latitude)
            
        except:
            print "\nAddress not found from Census Geocoder\n"
                   


        try:
            data_returned = runQuery(""'EXECUTE tlang5_dba.find_nearest_weather_station ('+str(latitude)+','+str(longitude)+',15);')[0]
            print "connected"
            
            chosen_weather_station = data_returned[0]
            weather_station_name = data_returned[1]
            distance_from_address = str(data_returned[2]) + " miles\n"

            run_weather_station = chosen_weather_station
            
            #print run_weather_station

            
            metadata_line = "Nearest weather station: " + chosen_weather_station +\
                            "\nWeather Station Name: " + weather_station_name +\
                            "\nDistance from entered location: " + distance_from_address

            for char in metadata_line:
                time.sleep(0.01)
                sys.stdout.write(char)
                sys.stdout.flush()

            img_name = (street[0:4]+'_'+city).replace(" ","")
            createStaticMap(img_coords,img_name)
            createImgWatermark(img_name)

            print "\n------------------------Nearest retailers------------------------"
            
        except:
            print "Weather station can't be printed"


            

        try:
            data_returned = runQuery(""'EXECUTE tlang5_dba.find_nearest_retailer ('+str(latitude)+','+str(longitude)+');')
            for each in data_returned:
                ln_print = "\n"

                if each[0] == 'WALMART':
                    walmart_store = str(each[1])
                    
                for i in each:
                    ln_print += str(i)+" "*(28-len(str(i))) + "|"

                    
                for char in ln_print:
                    time.sleep(0.01)
                    sys.stdout.write(char)
                    sys.stdout.flush()


            print "\n\n"
            data_returned = runQuery(""'EXECUTE tlang5_dba.get_weather_by_station(\''+chosen_weather_station+'\');')


            header_titles = ["OBS_DATE","TMAX","TMIN","PRCP","SNOW","SNWD"]
            header = ""
            for each in header_titles:
                header += str(each)+" "*(18-len(str(each))) + "|"


            #print header
            #print walmart_store

            for each in data_returned:
                ln_print = "\n"
                buffy = 60
                for i in each:
                    ln_print += str(i)+" "*(18-len(str(i))) + "|"
                    
##                for char in ln_print:
##                    #time.sleep(0.0001)
##                    sys.stdout.write(char)
##                    sys.stdout.flush()
        except:
            print "Yeah this"



        try:
            
            
            extraFunction(run_weather_station,walmart_store)
            inQuery("delete from tlang5_dba.template")
            
        except:
            print "Baby Agent"



       



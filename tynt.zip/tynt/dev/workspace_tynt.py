from colorama import init,Fore,Back,Style
from termcolor import colored
import os

# use Colorama to make Termcolor work on Windows too
init(autoreset=True)
os.system("mode con cols=80 lines=40")

with open("C:/Python27/sliced_py/tynt/dev/banner/open_banner.txt",'r') as banner_text:
    print Fore.GREEN + Style.BRIGHT + banner_text.read()


ok = raw_input("close")
